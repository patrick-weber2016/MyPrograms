// 9115 PairShare with Andrew Dobson

#include <iostream>
#include <cmath>
#include <iomanip> 
#include <string>

using namespace std;

int main()

{
	char(d) = ' ';
	int hold = 0;
	char(ch)= '+';
	cout << "C++ Fun!" << endl;
	cout << setw(13);


	cout << setw(6) << setfill('+') << ch << endl;
	cout << setw(6) << setfill('+') << ch << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(7) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(4) << setfill('+') << ch << setw(8) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(7) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(5) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(1) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(6) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(6) << setfill('+') << ch << setw(1) << setfill(' ') << d << setw(5) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(5) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(6) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(6) << setfill('+') << ch << setw(1) << setfill(' ') << d << setw(5) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(5) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill(' ') << d << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(8) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(5) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(6) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(3) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(7) << setfill(' ') << d << setw(8) << setfill('+') << ch << setw(4) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(8) << setfill(' ') << d << setw(4) << setfill('+') << ch << setw(2) << setfill(' ') << d << setw(2) << setfill('+') << ch << setw(2) << setfill(' ') << d << endl;
	cout << setw(6) << setfill('+') << ch << endl;
	cout << setw(6) << setfill('+') << ch << endl;




	cin >> hold;
	return 0;



}