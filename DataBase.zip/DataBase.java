 /**
TAC Student Database 
©WeberSoftwares 2016
Ms. Noble 2nd Semester Project
TAC 4th Hour
Revised v 4.08.2016
**/
package TAC;
/**
 * ©WeberSoftwares 2016
 * v 2.08.2016 (Original. see above for revised version)
 * Final (ready to release) version TBD
 * All Rights Reserved
 */
import javax.swing.*;

public class DataBase
{
    private String name;
    private String asset;
    private String client;
    private String ticket;
    private String notes;
    private final String sentinel = "e";
   public DataBase()
{
    // Windows look and feel
    try
    {
         UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
    }
        
     catch(ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
         // if the look and feel does not exist, throw exception
        throw new RuntimeException(e);
    }
    //Welcome and legality information
    JOptionPane.showMessageDialog(null,"Welcome to the TAC Ticket Tracking Software \n v 4.08.2016 \n ©WeberSoftwares 2016 All Rights Reserved.","Welcome", JOptionPane.INFORMATION_MESSAGE);
    // sets tech name
     name = JOptionPane.showInputDialog(null, "What is your name?");
 
     // will not accept empty field for name
    while(name.isEmpty())
    {
        JOptionPane.showMessageDialog(null, "Error 808: Name not found", "Name Error", JOptionPane.ERROR_MESSAGE);
        // forces reentry
        name = JOptionPane.showInputDialog(null, "What is your name?");
    }

    JOptionPane.showMessageDialog(null, String.format("Welcome, %s", name));
     client = JOptionPane.showInputDialog(null, "Enter the client's name.", "Client Info", JOptionPane.PLAIN_MESSAGE);
    // will not accept empty field for client
    while(client.isEmpty())
    {
        JOptionPane.showMessageDialog(null, "Error 1012: Missing Client Name. Please enter the client name", "Client Error", JOptionPane.ERROR_MESSAGE);
        // forces reentry
        client = JOptionPane.showInputDialog(null, "Enter the client's name.", "Client Info", JOptionPane.PLAIN_MESSAGE);
    }
    
     asset = JOptionPane.showInputDialog(null, "Enter the client's asset tag (Located on the green sticker on the bottom of the device.", "Device Info", JOptionPane.PLAIN_MESSAGE);
    // will not accept empty field for asset tag of computer
    while(asset.isEmpty())
    {
        JOptionPane.showMessageDialog(null, "Error 8437: Missing Device ID number. Enter the asset tag.", "Missing ID", JOptionPane.PLAIN_MESSAGE);
        // forces reentry
        asset = JOptionPane.showInputDialog(null, "Enter the client's asset tag (Located on the green sticker on the bottom of the device.", "Device Info", JOptionPane.PLAIN_MESSAGE);
    }
    // checks length validity of tag
    while(asset.length()!=6 || asset.isEmpty())
    {
        JOptionPane.showMessageDialog(null,"Error 3967: Tag length error. Please enter a valid asset tag.","Invalid tag number", JOptionPane.ERROR_MESSAGE); 
        //forces reentry
        asset = JOptionPane.showInputDialog(null, "Enter the client's asset tag (Located on the green sticker on the bottom of the device.)", "Device Info", JOptionPane.PLAIN_MESSAGE);
    }
    
         ticket = JOptionPane.showInputDialog(null, "What is the LSW TAC Work Tracker Ticket Number?", "Ticket", JOptionPane.PLAIN_MESSAGE);
    // checks ticket number
    while (ticket.isEmpty() || ticket.length()!=4)
    {
        JOptionPane.showMessageDialog(null,"Error 3141: Missing or Invalid Ticket Error. Enter 4 digit Ticket Number (taped to device).", "Ticket Error", JOptionPane.ERROR_MESSAGE);
        // forces reentry
        ticket = JOptionPane.showInputDialog(null, "What is the LSR7 TAC Work Tracker Ticket Number?", "Ticket", JOptionPane.PLAIN_MESSAGE);
    }
    // allows for multiple notes
    do
    {
       notes = JOptionPane.showInputDialog(null, "Enter all troubleshooting and repair notes for this ticket.\n Press 'Enter' between notes. \n Enter 'e' to exit this window","Notes", JOptionPane.PLAIN_MESSAGE);
       System.out.printf("%s%n",notes);
    }
    // sentinel kicks out of loop
    while (!sentinel.equals(notes));
    // no empty notes
    while (notes.isEmpty())
    {
        JOptionPane.showMessageDialog(null,"Error 4859: Missing process notes. Please enter notes","Missing Notes",JOptionPane.ERROR_MESSAGE);
        // forces reentry
         notes = JOptionPane.showInputDialog(null, "Enter all troubleshooting and repair notes for this ticket.\n Press 'Enter' between notes. \n Enter 'e' to exit this window","Notes", JOptionPane.PLAIN_MESSAGE);
    }
    //JOptionPane.showMessageDialog(null, String.format("%s%n%s%n%s%n%s%n%s%n", name,client,asset,ticket,notes));
    if (sentinel.equals(notes))
    {
        // graceful exit - sort of
     int exitButton =   JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit?", JOptionPane.YES_NO_CANCEL_OPTION);
    
     if(exitButton == JOptionPane.YES_OPTION)
     {
         JOptionPane.showMessageDialog(null, "Thank you for using the LSR7 TAC Ticket Tracking System");
         System.exit(0);
     }
     if (exitButton == JOptionPane.NO_OPTION || exitButton == JOptionPane.CANCEL_OPTION)
        notes = JOptionPane.showInputDialog(null, "Enter all troubleshooting and repair notes for this ticket.\n Press 'Enter' between notes. \n Enter 'e' to exit this window","Notes", JOptionPane.PLAIN_MESSAGE); 
     
    }
}
 
public static void main (String[] args)
{
       DataBase main = new DataBase();
}
}