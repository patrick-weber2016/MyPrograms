// OYO Phone Bill Patrick Weber 91515
// these are the required libraries for the code
#include <iostream>
#include <iomanip>
#include <cmath>

// this is the "universe" the commands will be extractd from 

using namespace std;

// this begins processing

int main()
{

	// these are the variables 
	int dayMinutes = 0;
	int nightMinutes = 0;
	int RMinutes = 0;
	int accountNumber = 0;
	char serviceType = 0;
	double Rtotal = 10.00;
	double ROver = 0;
	double RtotalCost = 0.00;
	double Ptotal = 25.00;
	double PtotalCost = 0.00;
	double pAMover = 0.00;
	double pPMover = 0.00;
	//this is  the first output; beginning of user visible code
	cout << "Wile E. Phone Company" << endl;
	cout << "Enter your account number" << endl;
	cin >> accountNumber;
	cout << "Enter your service type; P or p for premium and R or r for regular" << endl;
	cin >> serviceType;
	if (serviceType == 'R' || serviceType == 'r')
	{
		cout << "Enter the number of minutes the service was used. " << serviceType << endl;
		cin >> RMinutes;
		RtotalCost = Rtotal + (RMinutes - 50) * (.2);
		if (RMinutes <= 50)
		{
			cout << "Your total is: $10" << endl;
		}
		else
		{
			cout << "Your total is: " << RtotalCost << endl;

		}
	}

	else  if (serviceType == 'P' || serviceType == 'p')
	{
		cout << "Enter the minutes the service was used during the day. " << endl;
		cin >> dayMinutes;
		cout << "Enter the number of minutes the service was used at night." << endl;
		cin >> nightMinutes;
		if (dayMinutes > 75)

			pAMover = (dayMinutes - 75) * (.1);

		if (nightMinutes > 100)
			pPMover = (nightMinutes - 100)  * (.05);
		PtotalCost = Ptotal + pPMover + pAMover;
		cout << "Your total is: " << PtotalCost << endl;

	}
	else (serviceType !=  'P') || (serviceType !=  'p') || (serviceType != 'R') ||( serviceType != 'r');
	cout << "Invalid entry. Retry" << endl;
	system("pause");
}







