// Zachary Zoltek
// This is the reservation portion of Murphy's Roadkill Cafe
// Here you choose am/pm, a day and then a time. There are checks throughout to make sure that you don't enter something wrong
#include <iostream> //used for input and output
#include <string> //used to declare and search strings
#include <iterator> //used to iterate through the arrays for variables
#include <algorithm> //used to iterate
#include <stdlib.h> //this is for exit()
using namespace std;
bool cafeOpen = true;
bool StoreOpen = true;
bool dinnerOpen = true;
string day;
//flags to record if the stores are open or not
void timeSetup()
{
    //variable declarations
    char amPm;
    int hour;
    //array declarations. I declare these so that when the user enters the hour we can check them against the variable the 'x' preceeding all of them means 'unavailable'
    int xHoursCafe[5] = { 12, 1, 2, 3, 4 };
    int xHoursSouvWeekAm[8] = { 12, 1, 2, 3, 4, 5, 6, 7 };
    int xHoursSouvWeekPm[3] = { 9, 10, 11 };
    int xHoursSouvWeekendAm[] = { 12, 1, 2, 3, 4, 5, 6 };
    string ValidDays[7] = { "Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun" };
    //our beginning while loop for choosing am or pm
    while (true)
    {
		cout << "Welcome to Murphy's Roadkill Cafe! \n" << "We've got the best street meat around! \n \n";
        cout << "\n\nCafe Hours: 5am-11pm\n\nSouvenir Shop: 8am-8pm M-F, 7am-10pm weekends";
        cout << '\n' << '\n';
        cout << "Please specify AM (a|A) or PM (p|P)\n>";
        cin >> amPm;
        if (amPm != 'A' && amPm != 'a' && amPm != 'p' && amPm != 'P')
        {
            cout << "\n\nERROR: You did not enter a,A,P or p. Please try again\n\n";
            system("pause");
            exit(0);
        }
        system("cls");
        //while loop for the day arrival
        while (true)
        {
            cout << "Please specify the day you wish to arrive\n(Mon, Tue, Wed, Thur, Fri, Sat, Sun):";
            cin >> day;
            if (std::find(std::begin(ValidDays), std::end(ValidDays), day) == std::end(ValidDays))
            {
                cout << "\n\nNot a valid day!\n";
                system("pause");
                exit(0);
            }
            system("cls");
            break;
        }
        //while loop for the hour
        while (true)
        {
            system("cls");
            cout << "Please specify the hour(1-12):";
            cin >> hour;

            if (cin.fail() || hour > 12 || hour < 1)
            {
                cout << "\n\nERROR: Something seems to have gone wrong! Please specify a proper hour\n";
                system("pause");
                continue;
            }
            //here we begin the check for hours. In essence all we do is do check for the days, check for am or pm, and then depending on the previous two values, we check the proper hours
            //The way we check is by checking the userinputted hour against our arrays declared earlier, and if we find the user hour in the array, we flag the proper boolean as false, 
            //and tell them. If both are closed, we re-run the function since we cant really continue if everything is closed off
            if ((day == "Sat" || day == "Sun") && (amPm == 'a' || amPm == 'A'))
            {
                if (std::find(std::begin(xHoursSouvWeekendAm), std::end(xHoursSouvWeekendAm), hour) == std::end(xHoursSouvWeekendAm))
                {
                    StoreOpen = true;
                //    cout << "store set to true (1)" << endl;
                }
                else
                {
                    StoreOpen = false;
                //    cout << "store set to false (1)" << endl;
                }
                if (std::find(std::begin(xHoursCafe), std::end(xHoursCafe), hour) == std::end(xHoursCafe))
                {
                    cafeOpen = true;
                    if(hour == 11){
                        dinnerOpen = true;
                    }
                    else{
                        dinnerOpen = false;
                    }
                }
                else
                {
                    cafeOpen = false;
                    dinnerOpen = false;
                    
                }
            }
            if ((day == "Sat" || day == "Sun") && (amPm == 'p' || amPm == 'P'))
            {
                if (hour == 10)
                {
                    StoreOpen = false;
                    //cout << "store set to true (2)" << endl;;
                    cafeOpen = true;
                    if(hour == 8 || hour == 9 || hour == 10 || hour == 11)
                    {
                        dinnerOpen = false;
                    }
                    else
                    {
                        dinnerOpen = true;
                    }
                }
                else if (hour == 11)
                {
                    StoreOpen = false;
                //    cout << "store set to false (2)" << endl;;
                    cafeOpen = false;
                    dinnerOpen = false;
                }
				if (hour == 8 || hour == 9 || hour == 10 || hour == 11)
				{
					dinnerOpen = false;
				}
				else
				{
					dinnerOpen = true;
				}
            }
            else if ((amPm == 'P' || amPm == 'p') && (day != "Sat" && day != "Sun"))
            {
                if (std::find(std::begin(xHoursSouvWeekPm), std::end(xHoursSouvWeekPm), hour) == std::end(xHoursSouvWeekPm))
                {
                    StoreOpen = true;
                //    cout << "store set to true (3)" << endl;;
                    cafeOpen = true;
                    if(hour == 8 || hour == 9 || hour == 10 || hour == 11)
                    {
                        dinnerOpen = false;
                    }
                    else
                    {
						dinnerOpen = true;
                    }
                }
                else
                {
                    StoreOpen = false;
                //    cout << "store set to false (3)" << endl;;
                    if(hour == 11){cafeOpen = false;}
                    else{cafeOpen = true;}
                    if(hour == 8 || hour == 9 || hour == 10 || hour == 11)
                    {
                        dinnerOpen = false;
                    }
                    else
                    {
                        dinnerOpen = true;
                    }
                }
            }
            else if ((amPm == 'a' || amPm == 'A') && (day != "Sat" && day != "Sun"))
            {
                if (std::find(std::begin(xHoursSouvWeekAm), std::end(xHoursSouvWeekAm), hour) == std::end(xHoursSouvWeekAm))
                {
                    StoreOpen = true;
                //    cout << "store set to true {4}" << endl;
                }
                else
                {
                    StoreOpen = false;
                //    cout << "store set to false (4)" << endl;
                }

                if (std::find(std::begin(xHoursCafe), std::end(xHoursCafe), hour) == std::end(xHoursCafe))
                {
                    cafeOpen = true;
                    if(hour == 11)
                    {
                        dinnerOpen = true;
                    }
                    else
                    {
                        dinnerOpen = false;
                    }
                }
                else
                {
                    cafeOpen = false;
                    dinnerOpen = false;
                }
            }
           cout << '\n' << endl;
           cout << cafeOpen << ":cafe," << StoreOpen << ":store," << dinnerOpen << ":dinnner" << endl;
           system("pause");
           exit(0);

        }
    }
}
int main()
{
    timeSetup();
    return 0;
}