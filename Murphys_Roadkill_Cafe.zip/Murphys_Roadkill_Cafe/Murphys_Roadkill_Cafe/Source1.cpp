#include <iostream>
#include <iomanip>
#include <sstream>
#include <math.h>
#include <string>
#include <iterator> //used to iterate through the arrays for variables
#include <algorithm> //used to iterate
#include <stdlib.h> //this is for exit()
#include <Windows.h>
bool cafeOpen = true;
bool StoreOpen = true;
bool dinnerOpen = true;
using namespace std;

string purchacedItems[100]; //The two of these will be used to print a receipt
int itemNumber;
float foodTax = .04125;
float subtotal;
void souvenirShop();
float tiprate = 0;
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Beginning of Zachary Zoltek's section of this program
string timeSetup()
{
	//variable declarations
	char amPm;
	int hour;
	string day;
	//array declarations. I declare these so that when the user enters the hour we can check them against the variable the 'x' preceeding all of them means 'unavailable'
	int xHoursCafe[5] = { 12, 1, 2, 3, 4 };
	int xHoursSouvWeekAm[8] = { 12, 1, 2, 3, 4, 5, 6, 7 };
	int xHoursSouvWeekPm[3] = { 9, 10, 11 };
	int xHoursSouvWeekendAm[] = { 12, 1, 2, 3, 4, 5, 6 };
	string ValidDays[7] = { "Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun" };
	//our beginning while loop for choosing am or pm
	while (true)
	{
		cout << "Welcome to Murphy's Roadkill Cafe! \n" << "We've got the best street meat around! \n \n";
		cout << "\n\nCafe Hours: 5am-11pm\n\nSouvenir Shop: 8am-8pm M-F, 7am-10pm weekends";
		cout << '\n' << '\n';
		cout << "Please specify AM (a|A) or PM (p|P)\n>";
		cin >> amPm;
		if (amPm != 'A' && amPm != 'a' && amPm != 'p' && amPm != 'P')
		{
			cout << "\n\nERROR: You did not enter a,A,P or p. Please try again\n\n";
			system("pause");
			exit(0);
		}
		system("cls");
		//while loop for the day arrival
		while (true)
		{
			cout << "Please specify the day you wish to arrive\n\n(Mon, Tue, Wed, Thur, Fri, Sat, Sun):";
			cin >> day;
			if (std::find(std::begin(ValidDays), std::end(ValidDays), day) == std::end(ValidDays))
			{
				cout << "\n\nNot a valid day!\n";
				system("pause");
				exit(0);
			}
			system("cls");
			break;
		}
		//while loop for the hour
		while (true)
		{
			system("cls");
			cout << "Please specify the hour(1-12):";
			cin >> hour;

			if (cin.fail() || hour > 12 || hour < 1)
			{
				cout << "\n\nERROR: Something seems to have gone wrong! Please specify a proper hour\n";
				system("pause");
				continue;
			}
			//here we begin the check for hours. In essence all we do is do check for the days, check for am or pm, and then depending on the previous two values, we check the proper hours
			//The way we check is by checking the userinputted hour against our arrays declared earlier, and if we find the user hour in the array, we flag the proper boolean as false, 
			//and tell them. If both are closed, we re-run the function since we cant really continue if everything is closed off
			if ((day == "Sat" || day == "Sun") && (amPm == 'a' || amPm == 'A'))
			{
				if (std::find(std::begin(xHoursSouvWeekendAm), std::end(xHoursSouvWeekendAm), hour) == std::end(xHoursSouvWeekendAm))
				{
					StoreOpen = true;
					//    cout << "store set to true (1)" << endl;
				}
				else
				{
					StoreOpen = false;
					//    cout << "store set to false (1)" << endl;
				}
				if (std::find(std::begin(xHoursCafe), std::end(xHoursCafe), hour) == std::end(xHoursCafe))
				{
					cafeOpen = true;
					if (hour == 11){
						dinnerOpen = true;
					}
					else{
						dinnerOpen = false;
					}
				}
				else
				{
					cafeOpen = false;
					dinnerOpen = false;

				}
			}
			if ((day == "Sat" || day == "Sun") && (amPm == 'p' || amPm == 'P'))
			{
				if (hour == 10)
				{
					StoreOpen = false;
					//cout << "store set to true (2)" << endl;;
					cafeOpen = true;
					if (hour == 8 || hour == 9 || hour == 10 || hour == 11)
					{
						dinnerOpen = false;
					}
					else
					{
						dinnerOpen = true;
					}
				}
				else if (hour == 11)
				{
					StoreOpen = false;
					//    cout << "store set to false (2)" << endl;;
					cafeOpen = false;
					dinnerOpen = false;
				}
				if (hour == 8 || hour == 9 || hour == 10 || hour == 11)
				{
					dinnerOpen = false;
				}
				else
				{
					dinnerOpen = true;
				}
			}
			else if ((amPm == 'P' || amPm == 'p') && (day != "Sat" && day != "Sun"))
			{
				if (std::find(std::begin(xHoursSouvWeekPm), std::end(xHoursSouvWeekPm), hour) == std::end(xHoursSouvWeekPm))
				{
					StoreOpen = true;
					//    cout << "store set to true (3)" << endl;;
					cafeOpen = true;
					if (hour == 8 || hour == 9 || hour == 10 || hour == 11)
					{
						dinnerOpen = false;
					}
					else
					{
						dinnerOpen = true;
					}
				}
				else
				{
					StoreOpen = false;
					//    cout << "store set to false (3)" << endl;;
					if (hour == 11){ cafeOpen = false; }
					else{ cafeOpen = true; }
					if (hour == 8 || hour == 9 || hour == 10 || hour == 11)
					{
						dinnerOpen = false;
					}
					else
					{
						dinnerOpen = true;
					}
				}
			}
			else if ((amPm == 'a' || amPm == 'A') && (day != "Sat" && day != "Sun"))
			{
				if (std::find(std::begin(xHoursSouvWeekAm), std::end(xHoursSouvWeekAm), hour) == std::end(xHoursSouvWeekAm))
				{
					StoreOpen = true;
					//    cout << "store set to true {4}" << endl;
				}
				else
				{
					StoreOpen = false;
					//    cout << "store set to false (4)" << endl;
				}

				if (std::find(std::begin(xHoursCafe), std::end(xHoursCafe), hour) == std::end(xHoursCafe))
				{
					cafeOpen = true;
					if (hour == 11)
					{
						dinnerOpen = true;
					}
					else
					{
						dinnerOpen = false;
					}
				}
				else
				{
					cafeOpen = false;
					dinnerOpen = false;
				}
			}
			return day;

		}
	}
}
//End of Zachary Zoltek's Section of the Program
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Beginning of Gabriel Eorman's Section of the Program


void printArray(string arg[], int length, int listAmts[]) { // Because I like arrays
	int z = 1;
	for (int n = 1; n <= length; ++n)
	{
		cout << ' ' << "[" << listAmts[z-1] << "x] " << arg[n-1] << '\n' << '\n';
		z++;
	}
		
}

void printArray(string arg[], int length) { // Because I like arrays
	for (int n = 0; n < length; ++n)
		cout << ' ' << arg[n];
}

void purchace(string str, float cost) {
	str.append(" - ").append(to_string(cost)).append("\n");
	str.erase(str.end() - 6, str.end() - 2);
	purchacedItems[itemNumber] = str;
	subtotal = subtotal + cost;
	itemNumber++;
}


// time for the actual program

void cafe()
{

	//Variables
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

	//int dayOftheWeek;
	//float hourOfTheDay;
	char cont; //Check if the person wants to continue or skip
	//bool lunchTime;
	int menuNumber; //The number of the item on the menu


	string lunchNames[] = {
		"Mystery Meat",
		"Tapir Tacos",
		"Wombat Wellington",
		"Toasted Tortise",
		"Fried Fox",
		"Shrew Stew",
		"Sheep Slush"
	};
	int lunchAmts[] = { 20, 40, 90, 12, 78, 39, 47 };

	string lunchDesc[] = {
		" 1) Mystery Meat - $6.00 \n \t I hope you like suprises!",
		" 2) Tapir Tacos - $6.00 \n \t Three tacos made with Tapir meat. Tastes kinda like pork.",
		" 3) Wombat Wellington - $6.00 \n \t Wombat baked right into the center of some bread. Delicious!",
		" 4) Toasted Tortise - $6.00 \n \t The shell also functions as a nice bowl.",
		" 5) Fried Fox - $6.00 \n \t It sorta reminds me of chicken nuggets.",
		" 6) Shrew Stew - $6.00 \n \t Boil em', mash em', stick em' in a stew!\n\tShrews and potatoes can be exchanged, right?",
		" 7) Sheep Slush - $6.00 \n \t Don't worry, these lambs are 100% approved for sacrifice."
	};

	string menuNames[] = { //Available all day
		"Quail Quiche",
		"Baked Bat",
		"Snake Shake",
		"Pelican Pancakes",
		"Wolf Waffles",
	};

	string  breakfastDesc[] = {
		"1) Quail Quiche - $7.66 \n \t A delicious savory pastry full of custard and quail chunks. \n",
		"2) Baked Bat - $4.50 \n \t Some people call it \"Chicken of the Cave\" \n",
		"3) Snake Shake - $2.50 \n \t I\'m pretty sure that the scales provide protein. \n",
		"4) Pelican Pancakes - $5.33 \n \t What are you talking about? Meat on pancakes is totally a thing. \n",
		"5) Wolf Waffles - $7.00 \n \t Can you hear the call of the wild? \n"
	};

	float foodCosts[] = { 7.66, 4.50, 2.50, 5.33, 7.00 };
	float lunchCosts[] = { 8.90, 3.67, 12.50, 10.78, 15.00, 3.50, 8.90};

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
	//There's the end of that nightmare.

	//IGNORE THIS
	/*
	cout << "Welcome to Murphy's Roadkill Cafe! \n"
	<< "We've got the best street meat around! \n \n"
	<< "What day of the week would you like to visit us? (1 = Monday, 2 = Tuesday...) \n \n";

	cin >> dayOftheWeek;
	dayOftheWeek--;
	cin.ignore(100, '\n');
	cout << endl;

	cout << "Wonderful! We're open between 5:00 AM and 11:00 PM. \n"
	<< "We serve lunch between 11:00 AM and 8:00 PM. \n"
	<< "What time will you be arriving? (0.00-24.00) \n \n";

	cin >> hourOfTheDay;
	cin.ignore(100, '\n');
	cout << endl;

	// -- Use Time function instead -- //

	if ((hourOfTheDay <= 20.00) && (hourOfTheDay >= 11.00)) { lunchTime = true; } //If they intend to arrive between 11:00 AM and 8:00 PM, add lunch to the menu.
	else if ((hourOfTheDay >= 23.00) || (hourOfTheDay <= 5.00)) { cout << "Looks like you'll have to wait until we open, then! \n \n"; }; //We're closed, jerks.

	// -- Use Time function instead -- //
	*/
	//IGNORE THIS

	int dayOftheWeek;
	string day = timeSetup();
	system("cls");
	int menuChoice;
	if (cafeOpen == true)
	{
		if (dinnerOpen == true)
		{

		
			cout << "Dinner Menu is available\n\n";
			cout << "Please choose the menu you wish to look at:\n";
			cout << "[1] Lunch\n";
			cout << "[2] Breakfast\n";
			cout << "[3] Quit to the Souvenir Shop\n\n>";
				cin >> menuChoice;
			cin.ignore(100, '\n');
			if (menuChoice == 2)
			{
				system("cls");
				printArray(breakfastDesc, 5);
				cout << "\n\nWhat would you like to order? (0 to move on) \n \n";
				cin >> menuNumber;
				cout << endl;
				if ((menuNumber > 0) && (menuNumber <= 7)) {
					cin.ignore(100, '\n');
					purchace(menuNames[menuNumber - 1], foodCosts[menuNumber - 1]);
				};
				while (menuNumber != 0) {
					system("cls");
					printArray(breakfastDesc, 5);
					//reprint menu
					cout << "\n\nAnything else? (0 to move on) \n \n";
					cin >> menuNumber;
					cout << endl;
					if ((menuNumber > 0) && (menuNumber < 7)) {
						cin.ignore(100, '\n');
						purchace(menuNames[menuNumber - 1], foodCosts[menuNumber - 1]);
					};
				};
			}
			else if (menuChoice == 1)
			{
					system("cls");
					printArray(lunchDesc, 7, lunchAmts);
					cout << "\n\nWhat would you like to order? (0 to move on) \n \n";
					cin >> menuNumber;
					cout << endl;
					if ((menuNumber > 0) && (menuNumber <= 7)) {
						if (lunchAmts[menuNumber - 1] == 0)
						{
							system("cls");
							cout << "We have no more of that dish! Please select something else.\n\n";
							system("pause");
						}
						cin.ignore(100, '\n');
						purchace(lunchNames[menuNumber - 1], lunchCosts[menuNumber - 1]);
						lunchAmts[menuNumber - 1] -= 1;
					};
					while (menuNumber != 0) {
						if (lunchAmts[menuNumber - 1] == 0)
						{
							system("cls");
							cout << "We have no more of that dish! Please select something else.\n\n";
							system("pause");
						}
						system("cls");
						printArray(lunchDesc, 7, lunchAmts);
						//reprint menu
						cout << "\n\nAnything else? (0 to move on) \n \n";
						cin >> menuNumber;
						cout << endl;
						if ((menuNumber > 0) && (menuNumber <= 7)) {
							cin.ignore(100, '\n');
							purchace(lunchNames[menuNumber - 1], lunchCosts[menuNumber - 1]);
							lunchAmts[menuNumber - 1] -= 1;
						};
					}; 
			}
			else if (menuChoice == 3)
			{
				system("cls");
				cout << "Going to the shop!";
				souvenirShop();
			}
		}
		else
		{
			cout << "Dinner Menu is NOT available\n\n";
			cout << "Please choose the menu you wish to look at:\n";
			cout << "[1] Breakfast\n";
			cout << "[2] Quit to the Souvenir Shop\n\n>";
			cin >> menuChoice;
			cin.ignore(100, '\n');
			if (menuChoice == 1)
			{
				system("cls");
				printArray(breakfastDesc, 5);
				cout << "\n\nWhat would you like to order? (0 to move on) \n \n";
				cin >> menuNumber;
				cout << endl;
				if ((menuNumber > 0) && (menuNumber < 7)) {
					cin.ignore(100, '\n');
					purchace(menuNames[menuNumber - 1], foodCosts[menuNumber - 1]);
				};
				while (menuNumber != 0) {
					system("cls");
					printArray(breakfastDesc, 5);
					//reprint menu
					if (dinnerOpen == true) { cout << lunchDesc; };
					cout << "\n\nAnything else? (0 to move on) \n \n";
					cin >> menuNumber;
					cout << endl;
					if ((menuNumber > 0) && (menuNumber < 7)) {
						cin.ignore(100, '\n');
						purchace(menuNames[menuNumber - 1], foodCosts[menuNumber - 1]);
					};
				};
			}
			else if (menuChoice == 2)
			{
				system("cls");
				cout << "Going to the shop!";
				souvenirShop();
			}

		}
			
	}
	else if (cafeOpen == false)
	{
		if (StoreOpen == true)
		{
			system("cls");
			cout << "The cafe is closed, taking you to the souvenir store";
			system("pause");
			souvenirShop();
		}
		else if (StoreOpen == false)
		{
			system("cls");
			cout << "The store and the cafe are closed! Please attend at a different time.";
			system("pause");
		}
	}

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
		//End orders

		//Print the receipt
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
		cout << '\n' << '\n';
		system("cls");
		//End of Gabriel's Section of this Program
		//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//Beginng of Patrick Weber's Section of the Program
		double tip = 0;
		int rating = 0;
		string comment;
		// this will begin customer input prompting
		cout << "Thank you for choosing Murphy's Roadkill Cafe!\n" << endl;
		cout << "Please take time to fill out this customer satisfaction survey.\n" << endl;
		cout << "Input is 0, 1, or 2 with 2 being the best and 0 being the worst.\n" << endl;
		cin >> rating;
		if ((rating == 0 || rating == 1 || rating == 2) && (!cin.fail()))
		{
			cout << "\nThank you for feedback. Please come again.\n" << endl;
			system("pause");

		}
		else
		{
			cout << "Not a valid rating. Please try again." << endl;
			system("pause");
		}

		if
			(rating == 0)
		{
			system("cls");
			tiprate = .2;
			cout << "Tip:$" << subtotal*.2;
			cout << "\n\nYour total is:" << subtotal + (subtotal*.2) << '\n';

		}
		else
		if
			(rating == 1)
		{
			system("cls");
			tiprate = .15;
			cout << "Tip:$" << subtotal*.15;
			cout << "\n\nYour total is:" << subtotal + (subtotal*.15) << '\n';
		}
		else
		if
			(rating == 2)
		{
			system("cls");
			tiprate = .1;
			cout << "Tip:$" << subtotal*.1;
			cout << "\n\nYour total is:" << subtotal + (subtotal*.1) << '\n';

		}
		system("pause");
		system("cls");
		cout << endl;
		cout << "Would you like to leave a comment?" << endl;
		cout << endl;
		cin >> comment;
		cout << endl;
		cout << "Tene un dia fantastica! Adios!" << endl;

		cout << endl;
		cout << '\n' << '\n';
		system("pause");
		system("cls");
		cout << "Here is your receipt:\n";
		printArray(purchacedItems, itemNumber);
		cout << "\n\nTax:$" << subtotal*foodTax;
		cout << "\n\nTip:$" << subtotal*tiprate;
		cout << "\n\nTotal:$" << (subtotal + ((subtotal * foodTax) + (subtotal * tiprate)));
		//Ending of Patrick Weber's Section of the Program
		//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		cin >> cont;
		system("cls");
		if (StoreOpen == true)
		{
			souvenirShop();
		}
		else
		{
			cout << "The store is not open today! Farewell!\n\n";
			system("pause");
		}
	
} // end program

//Souvenir Shop
//Preston Ross's Code from here on out

void souvenirShop() {
	system("cls");
	//Inventory
	int numSnowglobes = 15;
	int numCandles = 30;
	int numChina = 5;
	int numTShirts = 50;
	int numMugs = 3;

	string buyOption = "Nothing";

	int numSnowglobesToBuy = 0;
	int numCandlesToBuy = 0;
	int numChinaToBuy = 0;
	int numTShirtsToBuy = 0;
	int numMugsToBuy = 0;

	int numSnowglobesBought = 0;
	int numCandlesBought = 0;
	int numChinaBought = 0;
	int numTShirtsBought = 0;
	int numMugsBought = 0;

	string keepShopping;
	float TotalOrderCost = 0.00;
	float Total = 0.00;





	const float TAXRATE = .0725;

	int hold;
	//Greeting
	cout << "Welcome to Murphy's souvenir shop." << endl;
	//Display greeting for 2 seconds before moving on
	Sleep(2000);


	//Asks what you want to buy until the user says no or No
	while (true)
	{
		system("CLS");
		cout << "At Murphy's souvenir shop, we sell: " << endl << endl;

		//In stock
		cout << "Snowglobes (" << numSnowglobes << ")" << endl;
		cout << setw(24) << "$5.00" << endl;

		cout << setw(0) << "Candles (" << numCandles << ")" << endl;
		cout << setw(24) << "$3.00" << endl;

		cout << setw(0) << "China (" << numChina << ")" << endl;
		cout << setw(24) << "$15.00" << endl;

		cout << setw(0) << "T-shirts (" << numTShirts << ")" << endl;
		cout << setw(24) << "$30.00" << endl;

		cout << setw(0) << "Mugs (" << numMugs << ")" << endl;
		cout << setw(24) << "$12.00" << endl;

		//selecting what to buy
		cout << "What would you like to buy? ";
		cin >> buyOption;


		//buying snowglobes
		if (buyOption == "Snowglobes" || buyOption == "snowglobes") {
			while (true) {
				cout << "How many would you like to buy? ";
				cin >> numSnowglobesToBuy;

				if (numSnowglobesToBuy <= numSnowglobes) {
					cout << "Thanks for buying our snowglobes." << endl;
					numSnowglobes = numSnowglobes - numSnowglobesToBuy;
					numSnowglobesBought = numSnowglobesBought + numSnowglobesToBuy;
					break;
				}
				else if (numSnowglobesToBuy > numSnowglobes) {
					cout << "We do not have that many snowglobes." << endl;
					continue;
				}
			}

		}


		//buying candles
		else if (buyOption == "Candles" || buyOption == "candles") {

			while (true) {
				cout << "How many would you like to buy? ";
				cin >> numCandlesToBuy;

				if (numCandlesToBuy <= numCandles) {
					cout << "Thanks for buying our candles." << endl;
					numCandles = numCandles - numCandlesToBuy;
					numCandlesBought = numCandlesBought + numCandlesToBuy;
					break;
				}
				else if (numCandlesToBuy > numCandles) {
					cout << "We do not have that many candles." << endl;
					continue;
				}

			}

		}


		//buying china
		else if (buyOption == "China" || buyOption == "china") {

			while (true) {
				cout << "How many would you like to buy? ";
				cin >> numChinaToBuy;

				if (numChinaToBuy <= numChina) {
					cout << "Thanks for buying our china." << endl;
					numChina = numChina - numChinaToBuy;
					numChinaBought = numChinaBought + numChinaToBuy;
					break;
				}
				else if (numChinaToBuy > numChina) {
					cout << "We do not have that many china." << endl;
					continue;
				}

			}

		}


		//buying T-shirts
		else if (buyOption == "T-shirts" || buyOption == "t-shirts" || buyOption == "Tshirts" || buyOption == "tshirts") {

			while (true) {
				cout << "How many would you like to buy? ";
				cin >> numTShirtsToBuy;

				if (numTShirtsToBuy <= numTShirts) {
					cout << "Thanks for buying our T-shirts." << endl;
					numTShirts = numTShirts - numTShirtsToBuy;
					numTShirtsBought = numTShirtsBought + numTShirtsToBuy;
					break;
				}
				else if (numTShirtsToBuy > numTShirts) {
					cout << "We do not have that many T-shirts." << endl;
					continue;
				}

			}

		}


		//buying mugs
		else if (buyOption == "Mugs" || buyOption == "mugs") {

			while (true) {
				cout << "How many would you like to buy? ";
				cin >> numMugsToBuy;

				if (numMugsToBuy <= numMugs) {
					cout << "Thanks for buying our mugs." << endl;
					numMugs = numMugs - numMugsToBuy;
					numMugsBought = numMugsBought + numMugsToBuy;
					break;
				}
				else if (numMugsToBuy > numMugs) {
					cout << "We do not have that many mugs." << endl;
					continue;
				}

			}

		}





		//End loop or not
		cout << "Would you like to continue shopping? ";
		cin >> keepShopping;
		if (keepShopping == "No" || keepShopping == "no" || keepShopping == "N" || keepShopping == "n")
		{
			system("CLS");
			break;
		}
		else
		{
			continue;
		}

	}

	//Displays totals with and without tax and shows subtotals for each item
	cout << fixed << setprecision(2);
	Total = (numSnowglobesBought * 5.00) + (numCandlesBought * 3.00) + (numChinaBought * 15.00) + (numTShirtsBought * 30.00) + (numMugsBought * 12.00);
	cout << "Your total is: $" << Total << " without tax" << endl;
	cout << "Snowglobes: $" << numSnowglobesBought * 5.00 << endl;
	cout << "Candles: $" << numCandlesBought * 3.00 << endl;
	cout << "China: $" << numChinaBought * 15.00 << endl;
	cout << "T-shirts: $" << numTShirtsBought * 30.00 << endl;
	cout << "Mugs: $" << numMugsBought * 12.00 << endl;


	cout << "Your total with tax is: $" << (Total * TAXRATE) + Total << endl;

	//holds screen until any key is pressed and then clears the screen
	system("pause");
	system("CLS");

	//Tells store what they need to order and how much it costs
	cout << "You will need to order: " << endl;
	cout << "Snowglobes (" << numSnowglobesBought << ")" << endl;
	cout << setw(24) << "$" << numSnowglobesBought * 3.00 << endl;
	cout << "Candles (" << numCandlesBought << ")" << endl;
	cout << setw(24) << "$" << numCandlesBought * 1.00 << endl;
	cout << "China (" << numChinaBought << ")" << endl;
	cout << setw(24) << "$" << numChinaBought * 10.00 << endl;
	cout << "T-shirts (" << numTShirtsBought << ")" << endl;
	cout << setw(24) << "$" << numTShirtsBought * 20.00 << endl;
	cout << "Mugs (" << numMugsBought << ")" << endl;
	cout << setw(24) << "$" << numMugsBought * 10.00 << endl;
	cout << "You will be charged a $50 fueling fee and $100 shipping fee with your order." << endl;

	TotalOrderCost = (numSnowglobesBought * 3.00) + (numCandlesBought * 1.00) + (numChinaBought * 10.00) + (numTShirtsBought * 20.00) + (numMugsBought * 10.00);

	cout << "Total order cost: $" << TotalOrderCost + 150 << endl;







	//ends the program when any key is pressed and returns 0
	system("pause");
}
int main()
{
	cafe();
	return 0;
}