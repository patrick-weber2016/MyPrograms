// Internet Pet Store Project  Patrick Weber 8/26/15
// This program is designed to emulate an online shopping cart 

#include <iostream>

using namespace std;

int main()

{

	const double costofGrizzlyBear = 2500.00;
	const  double costofLion = 4800.00;
	const double costofPhirana = 2300.00;
	const double costofBaldEagle = 15000.00;
	const double costofToucan = 5900.00;
	const double costofAlbinoTiger = 10000;
	int numberofLion=0;
	int numberofGrizzly=0;
	int numberofPhirana=0;
	int numberofEagle=0;
	int numberofToucan=0;
	int numberofTiger=0;
	int totalAnimal=0;
	// This is the integral values accepted for animals
	double subtotal = 0.00;
		// This is the total cost with  NO shipping charge
		double total = 0.00;
	// This is the final total WITH shipping charge
	cout << "Weber Exotic Pets" << endl;
	// This is where I will display the name of my store
	cout << "We sell perfectly legal exotics pets" << endl;
	// This is a very short (and extremely ironic) description of my store
	cout << "How many Grizzly Bears would you like to purchase?" << endl;
	cin >> numberofGrizzly;
	cout << "How many Lions would you like to purchase?" << endl;
	cin >> numberofLion;
	cout << "How many Bald Eagles would you like to purchase?" << endl;
	cin >> numberofEagle;
	cout << "How many  Phiranas would you like to purchase?" << endl;
	cin >> numberofPhirana;
	cout << "How many Toucans would you like to purchase?" << endl;
	cin >> numberofToucan;
	cout << "How many Tigers (Albino) would you like to purchase?" << endl;
	cin >> numberofTiger;
	subtotal = (costofGrizzlyBear*numberofGrizzly) + (costofLion*numberofLion) + (costofPhirana*numberofPhirana) + (costofBaldEagle*numberofEagle) + (costofToucan*numberofToucan) + (costofAlbinoTiger*numberofTiger);
	cout << "Subtotal Due:" << endl;
	cout << subtotal << endl;
	cout << "There is a flat rate $50 shipping fee per animal added to your total cost" << endl;
	// This was added simply as a courtesy to my customers.
	total = subtotal + (50 * totalAnimal);
	cout << "Total Due:" << endl;
	cout << total << endl;
	cout << "Thank you for shopping at Weber Exotic Pets. Have a nice day!" << endl;
	// I added this because of my background in food service and customer service.
	int hold = 0;
	cin >> hold;
	return 0;





}

