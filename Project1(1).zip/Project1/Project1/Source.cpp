// Namebuilder Project Patrick Weber 091515

#include <iostream>
#include <iomanip>

using namespace std;

int main()

{
	cout << "PAW16" << endl;
	cout << "PPPPPPPPPP   PPPPPPPP  PPP  PPP  PPP  PPP  PPPPP" << endl;
	cout << "PPP    PPP   PP    PP  PPP  PPP  PPP  PPP  PPPPP" << endl;
	cout << "PPP    PPP   PP    PP  PPP  PPP  PPP  PPP  PP" << endl;
	cout << "PPP    PPP   PPPPPPPP  PPP  PPP  PPP  PPP  PPPPPPPP" << endl;
	cout << "PPP    PPP   PP    PP  PPP  PPP  PPP  PPP  PP   PPP" << endl;
	cout << "PPP    PPP   PP    PP  PPP  PPP  PPP  PPP  PP   PPP" << endl;
	cout << "PPPPPPPPPP   PP    PP  PPP  PPP  PPP  PPP  PPPPPPP" << endl;
	cout << "PPP                       PP   PP" << endl;
	cout << "PPP                       PP   PP" << endl;
	cout << "PPP" << endl;
	cout << "PPP" << endl;
	system("pause");
}